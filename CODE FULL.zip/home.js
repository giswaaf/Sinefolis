let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {
    slideIndex = 1;
  }
  slides[slideIndex - 1].style.display = "block";
  setTimeout(showSlides, 8000); // Ubah gambar setiap 3 detik
}

function plusSlides(n) {
  slideIndex += n;
  if (slideIndex > document.getElementsByClassName("mySlides").length) {
    slideIndex = 1;
  }
  if (slideIndex < 1) {
    slideIndex = document.getElementsByClassName("mySlides").length;
  }
  showSlidesManually();
}

function showSlidesManually() {
  let slides = document.getElementsByClassName("mySlides");
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex - 1].style.display = "block";
}

// Mobile Menu Toggle
const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("active");
});

// Close mobile menu when clicking a link
document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("active");
  });
});

// Hero Background Changer
const hero = document.querySelector(".hero");
const heroBackgrounds = [
  'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url("https://source.unsplash.com/random/1920x1080/?cinema")',
  'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url("https://source.unsplash.com/random/1920x1080/?movie-theater")',
  'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url("https://source.unsplash.com/random/1920x1080/?hollywood")',
];
let currentHeroBg = 0;

function changeHeroBackground() {
  hero.style.background = heroBackgrounds[currentHeroBg];
  currentHeroBg = (currentHeroBg + 1) % heroBackgrounds.length;
}

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });

  // Close menu when clicking a link
  document.querySelectorAll(".nav-links a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("active");
    });
  });
}

// Jika ingin menambahkan fungsi khusus untuk halaman cinema
if (window.location.pathname.includes("cinema.html")) {
  // Bisa ditambahkan animasi khusus untuk halaman cinema
  const locationCards = document.querySelectorAll(".location-card");

  locationCards.forEach((card) => {
    card.addEventListener("click", () => {
      // Contoh: redirect ke halaman detail cinema
      // window.location.href = 'cinema-detail.html';
    });
  });
}

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });

  // Close menu when clicking a link
  document.querySelectorAll(".nav-links a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("active");
    });
  });
}

if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });

  // Close menu when clicking a link
  document.querySelectorAll(".nav-links a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("active");
    });
  });
}

// Thank You Page Redirection
if (window.location.pathname.includes("faqsub.html")) {
  // Start countdown to redirect
  setTimeout(() => {
    // Add fade out animation before redirect
    document.querySelector(".thank-you-container").style.animation =
      "fadeOut 1.5s ease-in-out";

    // Wait for animation to complete before redirect
    setTimeout(() => {
      window.location.href = "home.html";
    }, 1500);
  }, 8000); // 8 seconds delay
}
